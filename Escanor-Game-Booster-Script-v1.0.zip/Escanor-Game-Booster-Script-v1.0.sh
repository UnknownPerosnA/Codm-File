#!/system/bin/sh
echo "Escanor Game Booster Script v1.0"
sleep 0.5
echo ""
echo " [ Information About ] "
sleep 1
echo "•PuppieGaming•"
echo " Developer : @AljoPH "
sleep 1
echo ""
echo " [ Check Your Device ] "
echo "• ID Device    » $(getprop ro.product.model)"
sleep 1.5
echo "• ID Brand     » $(getprop ro.product.system.brand)"
sleep 1.5
echo "• ID Model     » $(getprop ro.build.product)"
sleep 1.5
echo "• ID Kernel    » $(uname -r)"
sleep 1.5
echo "• ID Chipset   » $(getprop ro.product.board)"
sleep 5
echo ""
echo " [ SUPPORT ME ON ] "
sleep 1
echo "YouTube: Puppie Gaming Official "
echo "Telegram: PuppieGaming "
sleep 1
echo ""
echo " > Applying Script To The Device < "
sleep 5
echo "[■□□□□□□□□□] 10% "
sleep 1
echo "[■■□□□□□□□□] 20% "
sleep 2
echo "[■■■□□□□□□□] 30% "
sleep 1
echo "[■■■■□□□□□□] 40% "
sleep 2
echo "[■■■■■□□□□□] 50% "
sleep 1
echo "[■■■■■■□□□□] 60% "
sleep 2
echo "[■■■■■■■□□□] 70% "
sleep 1
echo "[■■■■■■■■□□] 80% "
sleep 2
echo "[■■■■■■■■■□] 90% "
sleep 5
echo "[■■■■■■■■■■] 100% "
sleep 5
echo ""
apply_string () {
cmd game mode performance com.mobile.legends
cmd game mode performance com.dts.freefireth
cmd game mode performance com.tencent.ig
cmd game mode performance com.dts.freefiremax
cmd game mode performance com.garena.game.codm
cmd game mode performance com.activision.callofduty.shooter
cmd game mode performance com.ForgeGames.SpecialForcesGroup2
cmd game mode performance com.pubg.imobile
cmd game mode performance com.netease.newspike
cmd game mode performance com.ea.gp.fifamobile
cmd power set-fixed-performance-mode-enabled true
cmd activity kill-all
cmd thermalservice override-status 0
setprop debug.sf.early.app.duration 800000
setprop debug.sf.early.sf.duration 800000
setprop debug.sf.earlyGl.app.duration 800000
setprop debug.sf.earlyGl.sf.duration 800000
setprop debug.sf.early_app_phase_offset_ns 800000
setprop debug.sf.early_gl_app_phase_offset_ns 800000
setprop debug.sf.early_phase_offset_ns 800000
setprop debug.sf.high_fps.early.app.duration 800000
setprop debug.sf.high_fps.early.sf.duration 800000
setprop debug.sf.high_fps.earlyGl.app.duration 800000
setprop debug.sf.high_fps.hwc.min.duration 1250000
setprop debug.sf.high_fps.late.app.duration 1250000
setprop debug.sf.high_fps.late.sf.duration 1250000
setprop debug.sf.high_fps_early_app_phase_offset_ns 800000
setprop debug.sf.high_fps_early_cpu_app_offset_ns 60
setprop debug.sf.high_fps_early_gl_app_phase_offset_ns 800000
setprop debug.sf.high_fps_early_gpu_app_offset_ns 60
setprop debug.sf.high_fps_early_phase_offset_ns 800000
setprop debug.sf.high_fps_late_app_phase_offset_ns 1250000
setprop debug.sf.high_fps_late_gl_phase_offset_ns 1250000
setprop debug.sf.high_fps_late_phase_offset_ns 1250000
setprop debug.sf.high_fps_late_sf_phase_offset_ns 1250000
setprop debug.sf.perf_fps_early_gl_phase_offset_ns 800000
setprop debug.egl.native_scaling true
setprop debug.performance_schema true
setprop debug.OVRManager.cpuLevel 2
setprop debug.OVRManager.gpuLevel 2
settings put secure speed_mode_enable 1
settings put system speed_mode 1
setprop debug.app.performance_restricted false
setprop debug.performance.tuning 1
setprop debug.performance_schema_max_memory_classes 10
setprop debug.performance_schema_max_socket_classes 5
setprop debug.hwui.disable_fbo_cache true
setprop debug.hwui.disable_gpu_cache true
setprop debug.hwui.disable_picture_cache true
setprop debug.hwui.disable_text_cache true
setprop debug.hwui.disable_path_cache true
setprop debug.hwui.disable_asset_cache true
setprop debug.hwui.renderer opengl
setprop debug.hwui.layer_cache_size 128
setprop debug.hwui.path_cache_size 16
setprop debug.hwui.drop_shadow_cache_size 12
setprop debug.hwui.gradient_cache_size 4
setprop debug.hwui.enable_texture_atlas true
setprop debug.hwui.enable_overdraw_detection true
setprop debug.hwui.show_overdraw true
setprop debug.hwui.overdraw_color 0xFFFF0000
setprop debug.hwui.use_buffer_age false
setprop debug.hwui.disable_vsync true
setprop debug.hwui.render_dirty_regions false
setprop debug.performance.profile 1
setprop debug.graphics.enable_tracing 1
setprop debug.hwui.texture_cache_size 128
setprop debug.hwui.layer_cache_size 64
setprop debug.hwui.path_cache_size 8
setprop debug.hwui.drop_shadow_cache_size 6
setprop debug.hwui.gradient_cache_size 2
setprop debug.hwui.enable_texture_atlas true
setprop debug.sf.showupdates 0
setprop debug.sf.showcpu 0
setprop debug.sf.showbackground 0
setprop debug.sf.showfps 0
setprop debug.performance_hint 1
setprop debug.composition.type c2d
setprop debug.egl.hw 1
setprop debug.enabletr true
setprop debug.overlayui.enable 1
setprop debug.sf.hw 1
}
> /dev/null 2>&1
echo""
sleep 1
echo ""
echo " > Finishing Process < "
sleep 5
echo "[■□□□□□□□□□] 10% "
sleep 1
echo "[■■□□□□□□□□] 20% "
sleep 2
echo "[■■■□□□□□□□] 30% "
sleep 1
echo "[■■■■□□□□□□] 40% "
sleep 2
echo "[■■■■■□□□□□] 50% "
sleep 1
echo "[■■■■■■□□□□] 60% "
sleep 2
echo "[■■■■■■■□□□] 70% "
sleep 1
echo "[■■■■■■■■□□] 80% "
sleep 2
echo "[■■■■■■■■■□] 90% "
sleep 5
echo "[■■■■■■■■■■] 100% "
sleep 5
echo ""
echo "Successfully Applied"
echo ""
echo "Escanor Game Booster Script v1.0"
echo ""
echo "> Script Features <
• Boost Cpu - Gpu
• Boost Graphic
• Boost Fps Drop
• Boost Frame Rate
• Boost Screen
• Boost Touch Screen
• Speed Up x2
• High Fps
• High Refresh Rate"
echo ""
echoc "> Game Boosted <
Free Fire
Mobile Legends
Call Of Duty Global
Call Of Duty Garena
Blood Strike
Pubg Mobile
Battle Ground Mobile India
Special Force Group 2"
echo ""
echo "Enjoy Your Game"