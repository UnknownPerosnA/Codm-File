#!/system/bin/sh
echo "Escanor Game Booster Script v1.2"
sleep 0.5
echo ""
echo " [ Information About ] "
sleep 1
echo "•PuppieGaming•"
echo " Developer : @AljoPH "
sleep 1
echo ""
echo " [ Check Your Device ] "
echo "• ID Device    » $(getprop ro.product.model)"
sleep 1.5
echo "• ID Brand     » $(getprop ro.product.system.brand)"
sleep 1.5
echo "• ID Model     » $(getprop ro.build.product)"
sleep 1.5
echo "• ID Kernel    » $(uname -r)"
sleep 1.5
echo "• ID Chipset   » $(getprop ro.product.board)"
sleep 5
echo ""
echo " [ SUPPORT ME ON ] "
sleep 1
echo "YouTube: Puppie Gaming Official "
echo "Telegram: PuppieGaming "
sleep 1
echo ""
echo " > Applying Script To The Device < "
sleep 5
echo "[■□□□□□□□□□] 10% "
sleep 1
echo "[■■□□□□□□□□] 20% "
sleep 2
echo "[■■■□□□□□□□] 30% "
sleep 1
echo "[■■■■□□□□□□] 40% "
sleep 2
echo "[■■■■■□□□□□] 50% "
sleep 1
echo "[■■■■■■□□□□] 60% "
sleep 2
echo "[■■■■■■■□□□] 70% "
sleep 1
echo "[■■■■■■■■□□] 80% "
sleep 2
echo "[■■■■■■■■■□] 90% "
sleep 5
echo "[■■■■■■■■■■] 100% "
echo ""
checking_config() {
device_config get game_overlay com.ea.gp.apexlegendsmobilefps
device_config get game_overlay com.mobile.legends
device_config get game_overlay com.garena.game.codm
device_config get game_overlay com.dts.freefiremax
device_config get game_overlay com.dts.freefireth
device_config get game_overlay com.miHoYo.GenshinImpact
device_config get game_overlay com.tencent.ig
device_config get game_overlay com.pubg.newstate
device_config get game_overlay com.shooter.modernWarships
device_config get game_overlay com.carxtech.sr
device_config get game_overlay com.pubg.imobile
device_config get game_overlay com.pubg.krmobile
device_config get game_overlay com.HoYoverse.hkrpgoversea
device_config get game_overlay com.roblox.client
device_config get game_overlay com.ngame.allstar.eu
device_config get game_overlay com.garena.game.lmjx
device_config get game_overlay com.miHoYo.bh3global
device_config get game_overlay com.epicgames.fortnite
device_config get game_overlay com.minecraftpe.minecraft.original.free
device_config get game_overlay com.proximabeta.mf.uamo
device_config get game_overlay net.wargaming.wot.blitz
device_config get game_overlay com.mobilelegends.hwag
device_config get game_overlay com.ea.gp.fifamobile
device_config get game_overlay com.gameloft.android.ANMP.GloftA8HM
device_config get game_overlay com.igg.android.vikingriseglobal
device_config get game_overlay com.axlebolt.standoff2
device_config get game_overlay com.kurogame.gplay.punishing.grayraven.en
device_config get game_overlay com.kakaogames.gdts
device_config get game_overlay com.netease.newspike
device_config get game_overlay jp.konami.pesam
device_config get game_overlay com.axlebolt.standoff2
device_config get game_overlay com.bycodec.project_drift
device_config get game_overlay com.miniclip.eightballpool
device_config get game_overlay com.ea.gp.nfsm
device_config get game_overlay com.ForgeGames.SpecialForcesGroup2
device_config get game_overlay com.activision.callofduty.shooter
}

echo "⦿ Checking Game Mode Interventions "
sleep 1

setup_config() {
device_config put game_overlay com.ea.gp.apexlegendsmobilefps mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
device_config put game_overlay com.mobile.legends mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
device_config put game_overlay com.garena.game.codm mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
device_config put game_overlay com.dts.freefiremax mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
device_config put game_overlay com.dts.freefireth mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
device_config put game_overlay com.miHoYo.GenshinImpact mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
device_config put game_overlay com.tencent.ig mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
device_config put game_overlay com.pubg.newstate mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
device_config put game_overlay com.shooter.modernWarships mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
device_config put game_overlay com.carxtech.sr mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
device_config put game_overlay com.pubg.imobile mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
device_config put game_overlay com.pubg.krmobile mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
device_config put game_overlay com.HoYoverse.hkrpgoversea mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
device_config put game_overlay com.roblox.client mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90

device_config put game_overlay com.ngame.allstar.eu mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
device_config put game_overlay com.garena.game.lmjx mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
device_config put game_overlay com.miHoYo.bh3global mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
device_config put game_overlay com.epicgames.fortnite mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
device_config put game_overlay com.minecraftpe.minecraft.original.free mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
device_config put game_overlay com.proximabeta.mf.uamo mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
device_config put game_overlay net.wargaming.wot.blitz mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
device_config put game_overlay com.mobilelegends.hwag mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
device_config put game_overlay com.ea.gp.fifamobile mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
device_config put game_overlay com.gameloft.android.ANMP.GloftA8HM mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
device_config put game_overlay com.igg.android.vikingriseglobal mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
device_config put game_overlay com.axlebolt.standoff2 mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
device_config get game_overlay com.kurogame.gplay.punishing.grayraven.en mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
device_config get game_overlay com.kakaogames.gdts mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
device_config get game_overlay com.netease.newspike mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
device_config get game_overlay jp.konami.pesam mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
device_config get game_overlay com.axlebolt.standoff2 mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
device_config get game_overlay com.bycodec.project_drift mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
device_config get game_overlay com.miniclip.eightballpool mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
device_config get game_overlay com.ea.gp.nfsm mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
device_config get game_overlay com.activision.callofduty.shooter mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
device_config get game_overlay com.ForgeGames.SpecialForcesGroup2 mode=2,skiagl=1,downscaleFactor=0.9,fps=90:mode=3,skiagl=0,downscaleFactor=0.9,fps=90
}
echo "⦿ Set Up Config Game "
sleep 1

compile_secondary() {
cmd package compile -m secondary -f com.ea.gp.apexlegendsmobilefps
cmd package compile -m secondary -f com.mobile.legends
cmd package compile -m secondary -f com.garena.game.codm
cmd package compile -m secondary -f com.dts.freefiremax
cmd package compile -m secondary -f com.dts.freefireth
cmd package compile -m secondary -f com.miHoYo.GenshinImpact
cmd package compile -m secondary -f com.tencent.ig
cmd package compile -m secondary -f com.pubg.newstate
cmd package compile -m secondary -f com.shooter.modernWarships
cmd package compile -m secondary -f com.carxtech.sr
cmd package compile -m secondary -f com.pubg.imobile
cmd package compile -m secondary -f com.pubg.krmobile
cmd package compile -m secondary -f com.HoYoverse.hkrpgoversea
cmd package compile -m secondary -f com.roblox.client
cmd package compile -m secondary -f com.ngame.allstar.eu
cmd package compile -m secondary -f com.garena.game.lmjx

cmd package compile -m secondary -f com.miHoYo.bh3global
cmd package compile -m secondary -f com.epicgames.fortnite
cmd package compile -m secondary -f com.minecraftpe.minecraft.original.free
cmd package compile -m secondary -f com.proximabeta.mf.uamo
cmd package compile -m secondary -f net.wargaming.wot.blitz
cmd package compile -m secondary -f com.mobilelegends.hwag
cmd package compile -m secondary -f com.ea.gp.fifamobile
cmd package compile -m secondary -f com.gameloft.android.ANMP.GloftA8HM
cmd package compile -m secondary -f com.igg.android.vikingriseglobal
cmd package compile -m secondary -f com.axlebolt.standoff2
cmd package compile -m secondary -f com.kurogame.gplay.punishing.grayraven.en
cmd package compile -m secondary -f com.kakaogames.gdts
cmd package compile -m secondary -f com.netease.newspike
cmd package compile -m secondary -f jp.konami.pesam
cmd package compile -m secondary -f com.axlebolt.standoff2
cmd package compile -m secondary -f com.bycodec.project_drift
cmd package compile -m secondary -f com.miniclip.eightballpool
cmd package compile -m secondary -f com.ea.gp.nfsm
cmd package compile -m secondary -f com.activision.callofduty.shooter
cmd package compile -m secondary -f com.ForgeGames.SpecialForcesGroup2
}
echo "⦿ Compile Secondary "
sleep 1

setup_game_mode() {
cmd game mode performance com.ea.gp.apexlegendsmobilefps
cmd game mode performance com.mobile.legends
cmd game mode performance com.garena.game.codm
cmd game mode performance com.dts.freefiremax
cmd game mode performance com.dts.freefireth
cmd game mode performance com.miHoYo.GenshinImpact
cmd game mode performance com.tencent.ig
cmd game mode performance com.pubg.newstate
cmd game mode performance com.shooter.modernWarships
cmd game mode performance com.carxtech.sr
cmd game mode performance com.pubg.imobile
cmd game mode performance com.pubg.krmobile
cmd game mode performance com.HoYoverse.hkrpgoversea
cmd game mode performance com.roblox.client
cmd game mode performance com.ngame.allstar.eu
cmd game mode performance com.garena.game.lmjx
cmd game mode performance com.miHoYo.bh3global
cmd game mode performance com.epicgames.fortnite
cmd game mode performance com.minecraftpe.minecraft.original.free
cmd game mode performance com.proximabeta.mf.uamo
cmd game mode performance net.wargaming.wot.blitz
cmd game mode performance com.mobilelegends.hwag
cmd game mode performance com.ea.gp.fifamobile
cmd game mode performance com.gameloft.android.ANMP.GloftA8HM
cmd game mode performance com.igg.android.vikingriseglobal
cmd game mode performance com.axlebolt.standoff2
cmd game mode performance com.kurogame.gplay.punishing.grayraven.en
cmd game mode performance com.kakaogames.gdts
cmd game mode performance com.netease.newspike
cmd game mode performance jp.konami.pesam
cmd game mode performance com.axlebolt.standoff2
cmd game mode performance com.bycodec.project_drift
cmd game mode performance com.miniclip.eightballpool
cmd game mode performance com.ea.gp.nfsm
cmd game mode performance com.activision.callofduty.shooter
cmd game mode performance com.ForgeGames.SpecialForcesGroup2
}
echo "⦿ Set Up Game Mode Performance "
sleep 1

setup_jit() {
cmd package compile -m speed -f com.ea.gp.apexlegendsmobilefps
cmd package compile -m speed -f com.mobile.legends
cmd package compile -m speed -f com.garena.game.codm
cmd package compile -m speed -f com.dts.freefiremax
cmd package compile -m speed -f com.dts.freefireth
cmd package compile -m speed -f com.miHoYo.GenshinImpact
cmd package compile -m speed -f com.tencent.ig
cmd package compile -m speed -f com.pubg.newstate
cmd package compile -m speed -f com.shooter.modernWarships
cmd package compile -m speed -f com.carxtech.sr
cmd package compile -m speed -f com.pubg.imobile
cmd package compile -m speed -f com.pubg.krmobile
cmd package compile -m speed -f com.HoYoverse.hkrpgoversea
cmd package compile -m speed -f com.roblox.client
cmd package compile -m speed -f com.ngame.allstar.eu
cmd package compile -m speed -f com.garena.game.lmjx
cmd package compile -m speed -f com.miHoYo.bh3global

cmd package compile -m speed -f com.epicgames.fortnite
cmd package compile -m speed -f com.minecraftpe.minecraft.original.free
cmd package compile -m speed -f com.proximabeta.mf.uamo
cmd package compile -m speed -f net.wargaming.wot.blitz
cmd package compile -m speed -f com.mobilelegends.hwag
cmd package compile -m speed -f com.ea.gp.fifamobile
cmd package compile -m speed -f com.gameloft.android.ANMP.GloftA8HM
cmd package compile -m speed -f com.igg.android.vikingriseglobal
cmd package compile -m speed -f com.axlebolt.standoff2
cmd package compile -m speed -f com.kurogame.gplay.punishing.grayraven.en
cmd package compile -m speed -f com.kakaogames.gdts
cmd package compile -m speed -f com.netease.newspike
cmd package compile -m speed -f jp.konami.pesam
cmd package compile -m speed -f com.axlebolt.standoff2
cmd package compile -m speed -f com.bycodec.project_drift
cmd package compile -m speed -f com.miniclip.eightballpool
cmd package compile -m speed -f com.ea.gp.nfsm
cmd package compile -m speed -f com.activision.callofduty.shooter
cmd package compile -m speed -f com.ForgeGames.SpecialForcesGroup2
}
echo "⦿ Enabled JIT Performance mode for Games "
sleep 1

#Other Tweaks
(
setprop debug.hwui.renderer skiagl
setprop debug.renderengine.backend skiagl
setprop debug.renderengine.backend skiaglthreaded
setprop debug.angle.overlay FPS:skiagl*PipelineCache*
setprop debug.javafx.animation.framerate 120
setprop debug.systemuicompilerfilter speed
setprop debug.app.performance_restricted false
setprop debug.gr.numframebuffers 3
setprop debug.egl.force_fxaa false
setprop debug.egl.force_taa false
setprop debug.egl.force_msaa false
setprop debug.egl.force_ssaa false
setprop debug.egl.force_smaa false
setprop debug.egl.force_mlaa false
setprop debug.egl.force_txaa false
setprop debug.egl.force_csaa false
setprop debug.egl.buffcount 4
setprop debug.composition.type gpu
setprop debug.gr.numframebuffers 3
setprop debug.egl.buffcount 4
setprop debug.cpurend.vsync false
setprop debug.hwui.disable_invalidate 1
setprop debug.hwui.tiled_rendering true
setprop debug.enabletr true
setprop debug.overlayui.enable 1
setprop debug.egl.hw 0
setprop debug.gralloc.gfx_ubwc_disable 0
setprop debug.mdpcomp.logs 0
setprop debug.egl.hw 1
setprop debug.egl.profiler 0
setprop debug.performance.tuning 1
setprop debug.sf.hw 1
setprop debug.gr.swapinterval 1
setprop debug.egl.swapinterval 1
setprop debug.sf.showfps 0
setprop debug.sf.showcpu 0
setprop debug.sf.showbackground 0
setprop debug.sf.shoupdates 0
setprop debug.sf.set_idle_timer_ms 30
setprop debug.sf.disable_backpressure 1
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.enable_hwc_vds 1
setprop debug.kill_allocating_task 0
setprop debug.touchscreen.latency.scale 0,5
setprop debug.sf.early_phase_offset_ns 500000
setprop debug.sf.early_app_phase_offset_ns 500000
setprop debug.sf.early_gl_phase_offset_ns 3000000
setprop debug.sf.early_gl_app_phase_offset_ns 15000000
setprop debug.sf.high_fps_early_phase_offset_ns 6100000
setprop debug.sf.high_fps_late_sf_phase_offset_ns 8000000
setprop debug.sf.high_fps_early_gl_phase_offset_ns 9000000
setprop debug.sf.high_fps_late_app_phase_offset_ns 1000000
setprop debug.sf.high_fps_late_sf_phase_offset_ns 8000000
setprop debug.sf.high_fps_early_gl_phase_offset_ns 9000000
setprop debug.sf.phase_offset_threshold_for_next_vsync_ns 6100000
cmd power set-fixed-performance-mode-enabled true
settings put global performance.mode high
settings put system user_refresh_rate 120
settings put system peak_refresh_rate 120
settings put system thermal_limit_refresh_rate 120
settings put global gpu_renderer_policy 1
settings put global gpu_composition_policy 1
settings put global gpu_render_policy 1
settings put global enable_hw_2d 1
settings put global enable_hw_3d 1
settings put secure touch_exploration_enabled 1

settings put global animator_duration_scale 0.2
settings put global transition_animation_scale 0.2
settings put global window_animation_scale 0.2
settings put global activity_manager_constantsmax_cached_processes=1024
settings put system pointer_speed 7
settings put global max_cached_processes 22900
settings put global background_settle_time 0
settings put global fgservice_min_shown_time 0
settings put global fgservice_min_report_time 0
settings put global fgservice_screen_on_before_time 0
settings put global fgservice_screen_on_after_time 0
settings put global content_provider_retain_time 0
settings put global gc_timeout 0
settings put global full_pss_min_interval 0
settings put global full_pss_lowered_interval 0
settings put global power_check_interval 0
settings put global power_check_max_cpu_1 0
settings put global power_check_max_cpu_2 0
settings put global power_check_max_cpu_3 0
)> /dev/null 2>&1
echo""
sleep 1
echo ""
echo " > Finishing Process < "
sleep 5
echo "[■□□□□□□□□□] 10% "
sleep 1
echo "[■■□□□□□□□□] 20% "
sleep 2
echo "[■■■□□□□□□□] 30% "
sleep 1
echo "[■■■■□□□□□□] 40% "
sleep 2
echo "[■■■■■□□□□□] 50% "
sleep 1
echo "[■■■■■■□□□□] 60% "
sleep 2
echo "[■■■■■■■□□□] 70% "
sleep 1
echo "[■■■■■■■■□□] 80% "
sleep 2
echo "[■■■■■■■■■□] 90% "
sleep 5
echo "[■■■■■■■■■■] 100% "
sleep 5
echo ""
echo "Successfully Applied"
echo ""
echo "Escanor Game Booster Script v1.2"
echo ""
echo "> Script Features <
• Boost Cpu - Gpu
• Boost Graphic
• Boost Fps Drop
• Boost Frame Rate
• Boost Screen
• Boost Touch Screen
• Speed Up x2
• High Fps
• High Refresh Rate
• Enable JIT Performance
• Game Mode Performance
• Enable 90 Fps
• All Games Supported"
echo ""
echo ""
echo "Enjoy Your Game"